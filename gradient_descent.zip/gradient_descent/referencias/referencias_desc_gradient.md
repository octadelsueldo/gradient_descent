# Referencias

- https://towardsdatascience.com/logistic-regression-from-scratch-with-numpy-da4cc3121ece

- https://github.com/lmntrixsid/Linear-and-Logistic-Regression-with-NumPy-and-Python/blob/master/Logistic_Regression_Completed.ipynb

- https://towardsdatascience.com/gradient-descent-in-python-a0d07285742f

- https://towardsdatascience.com/implement-gradient-descent-in-python-9b93ed7108d1